# Programming Assignment 2: Conditional Variational Autoencoder

## Overview
Variational Autoencoders (VAEs) are powerful generative models that can learn to reconstruct and sample complex data distributions. However, sometimes we might want to control the generation process by specifying some desired attributes or conditions, such as the class, style, or content of the output. To address this limitation, [Conditional Variational Autoencoder (CVAE)](https://proceedings.neurips.cc/paper_files/paper/2015/file/8d55a249e6baa5c06772297520da2051-Paper.pdf) is proposed, which is a variant of VAE that incorporates a conditional variable into both the encoder and the decoder. Specifically, The encoder takes the input data and the conditional variable, and produces a latent representation that captures the relevant features of the data given the condition; The decoder takes the latent representation and the same conditional variable and generates an output that matches the data and the condition. The conditional variable can be anything that we want to use as a guide for the generation, such as a class label, a keyword, or a caption.


## Architecture of CVAE
Let's suppose the conditional variable is the class label, the architectures of VAE and CVAE are illustrated in Figure 1 and Figure 2, respectively.

<figure>
    <img src="images/VAE.png" width="800">
    <figcaption>Figure 1: Architecture of VAE.</figcaption>
</figure>

<figure>
    <img src="images/CVAE.png" width="800">
    <figcaption>Figure 2: Architecture of CVAE.</figcaption>
</figure>

From Figure 1 and Figure 2 we can see that, apart from the introduction of an encoder that encodes the conditional variable, another distinction between VAE and CVAE is that CVAE utilizes label information to ensure that the Gaussian distribution of each category $y$ has a unique mean value, rather than being equal to zero.


## Problem Descriptions
In this programming assignment, you need to implement three functions in [CVAE.py](./CVAE.py) and [train.py](./train.py). The detailed descriptions are as follows:
- **Question 1 (3 points): Implement the `Encoder_y` class in [CVAE.py](./CVAE.py)**. Encoder_y aims to encoder the label class variable $y$ using a single linear layer.
- **Question 2 (3 points): Implement the `forward()` function of `CVAE_Model` class in [CVAE.py](./CVAE.py)** based on the following formula:
  $$ \mu_{x}, \log{\sigma^{2}_{x}} = \text{encoder\_x}(x) $$ 
  $$ \mu_{y} = \text{encoder\_y}(y) $$ 
  $$ \hat{x} = \text{decoder}(\text{reparameterization}(\mu_{x}, \exp{(\frac{\log{\sigma^{2}_{x}}}{2})})) $$
- **Question 3 (4 points): Implement the KL divergence loss part in the `loss_fn` function in [train.py](./train.py)** based on the following formula:
  $$ L_{KLD} = -\frac{1}{2}\sum_{i = 1}^n\sum_{j = 1}^k(1 + \log{(\sigma_{x}^{(i, j)})^2} - (\mu_{x}^{(i, j)} - \mu_{y}^{(i, j)})^2 - (\sigma_{x}^{(i, j)})^2)  $$ 

  where $n$ is the number of samples, $k$ is the dimension of the latent embedding $z$(All samples have the same latent embedding dimension).
  
If your implementation is correct, the generated comparison.png should look similar to the following figure:
<figure>
    <img src="images/example.png">
    <figcaption>Figure 3: An example of the generated comparison.png.</figcaption>
</figure>


## Policies
Here are some key policies that you need to obey:
- Please submit the **entire project as a zip file** to the Tsinghua Web Learning Platform. The deadline is **May 4, 2024**.
- Please solve the problems individually. If you collaborate with others, please indicate that in your submission.
- Please feel free to define your own algorithms. **However, you are not allowed to use any packages not predefined in [CVAE.py](./CVAE.py) and [train.py](./train.py).** 
