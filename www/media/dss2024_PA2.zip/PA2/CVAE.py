import torch
import torch.nn as nn




'''
Encoder for the input data.
'''
class Encoder_x(nn.Module):
    
    def __init__(self, input_dim, hidden_dim, latent_dim):
        super().__init__()

        self.FC_input = nn.Linear(input_dim, hidden_dim)
        self.FC_input2 = nn.Linear(hidden_dim, hidden_dim)
        self.FC_mean = nn.Linear(hidden_dim, latent_dim)
        self.FC_var = nn.Linear (hidden_dim, latent_dim)
        self.LeakyReLU = nn.LeakyReLU(0.2)
        self.training = True
        

    def forward(self, x):
        h = self.LeakyReLU(self.FC_input(x))
        h = self.LeakyReLU(self.FC_input2(h))
        mean_x = self.FC_mean(h)
        log_var_x = self.FC_var(h)        
                                                    
        return mean_x, log_var_x
    


'''
Encoder for the class label.
Q1(3 points):  Implement the Encoder_y class.
Hint: the class label is encoded using a single linear layer. 
'''
class Encoder_y(nn.Module):

    def __init__(self, input_dim, latent_dim):
        super().__init__()

        self.training = True
        ## TO DO
        

    def forward(self, x):
        ## TO DO
        pass

    


class Decoder(nn.Module):

    def __init__(self, latent_dim, hidden_dim, output_dim):
        super().__init__()

        self.FC_hidden = nn.Linear(latent_dim, hidden_dim)
        self.FC_hidden2 = nn.Linear(hidden_dim, hidden_dim)
        self.FC_output = nn.Linear(hidden_dim, output_dim)
        self.LeakyReLU = nn.LeakyReLU(0.2)
        

    def forward(self, x):
        h = self.LeakyReLU(self.FC_hidden(x))
        h = self.LeakyReLU(self.FC_hidden2(h))
        x_hat = torch.sigmoid(self.FC_output(h))

        return x_hat
        


class CVAE_Model(nn.Module):

    def __init__(self, encoder_x, encoder_y, decoder, device):
        super().__init__()

        self.encoder_x = encoder_x
        self.encoder_y = encoder_y
        self.decoder = decoder
        self.device = device
        

    def reparameterization(self, mean, var):
        epsilon = torch.randn_like(var).to(self.device)  # sampling epsilon        
        z = mean + var * epsilon  # reparameterization trick

        return z
        
                
    def forward(self, x, y):
        ## Q2(3 points): Implement the forward function based on the following formula:
        ## mean_x, log_var_x = encoder_x(x)
        ## mean_y = encoder_y(y)
        ## x_hat = decoder(reparameterization(mean_x, exp^(log_var_x/2)))
        ## TO DO
        x_hat = None
        mean_x = None
        log_var_x = None
        mean_y = None
        
        return x_hat, mean_x, log_var_x, mean_y
    


    



