import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.optim import Adam
from torchvision.datasets import MNIST
import torchvision.transforms as transforms
import os
from tqdm import tqdm
import matplotlib.pyplot as plt
from CVAE import Encoder_x, Encoder_y, Decoder, CVAE_Model




def loss_fn(x, x_hat, mean_x, log_var_x, mean_y):
    reproduction_loss = nn.functional.binary_cross_entropy(x_hat, x, reduction = 'sum')
    ## Q3(4 points): Implement the KL divergence loss based on the formula provided in the README file
    ## TO DO
    KLD_loss = 0

    return reproduction_loss + KLD_loss



def load_data(dataset_path, batch_size):
    mnist_transform = transforms.Compose([transforms.ToTensor()])
    kwargs = {'num_workers': 0, 'pin_memory': False} 

    train_dataset = MNIST(root = dataset_path, transform = mnist_transform, train = True, download = False)
    test_dataset  = MNIST(root = dataset_path, transform = mnist_transform, train = False, download = False)

    train_loader = DataLoader(dataset = train_dataset, batch_size = batch_size, shuffle = True, **kwargs)
    test_loader  = DataLoader(dataset = test_dataset,  batch_size = batch_size, shuffle = False, **kwargs)

    return train_loader, test_loader


def train(model, train_loader, batch_size, lr, epochs, x_dim, y_dim, device):
    optimizer = Adam(model.parameters(), lr = lr)
    model.train()
    print("Start training CVAE...")
    
    for epoch in range(epochs):
        overall_loss = 0
        for batch_idx, (x, y) in enumerate(train_loader):
            x = x.view(batch_size, x_dim)
            x = x.to(device)
            y = F.one_hot(y, num_classes = y_dim)  # One-hot
            y = y.to(device, dtype = torch.float32)

            optimizer.zero_grad()

            x_hat, mean_x, log_var_x, mean_y = model(x, y)
            loss = loss_fn(x, x_hat, mean_x, log_var_x, mean_y)
            
            overall_loss += loss.item()
            
            loss.backward()
            optimizer.step()
            
        print("\tEpoch", epoch + 1, "complete!", "\tAverage Loss: ", overall_loss / (batch_idx * batch_size))
        
    print("Finish!!")

    checkpoint_save_dir = "/home/shitao/dss2024/PA2/checkpoints/" # change to your local path
    if not os.path.exists(checkpoint_save_dir):
        os.makedirs(checkpoint_save_dir)

    torch.save(model.state_dict(), os.path.join(checkpoint_save_dir,'CVAE.pth'))
    print('Checkpoint saved!')

    return model 



def eval(model, test_loader, batch_size, x_dim, y_dim, device):
    model.eval()

    with torch.no_grad():
        for _, (x, y) in enumerate(tqdm(test_loader)):
            x = x.view(batch_size, x_dim)
            x = x.to(device)
            y = F.one_hot(y, num_classes = y_dim)
            y = y.to(device, dtype = torch.float32)
            x_hat, _, _, _ = model(x, y)

            break
    
    return x, x_hat




if __name__ == '__main__':
    # model hyperparameters
    dataset_path = '/home/shitao/dss2024/PA2/dataset/' # change to your local path
    is_train = True
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    batch_size = 100
    x_dim  = 784
    y_dim = 10
    hidden_dim = 400
    latent_dim = 200
    lr = 1e-3
    epochs = 30

    # initialize model
    encoder_x = Encoder_x(input_dim = x_dim, hidden_dim = hidden_dim, latent_dim = latent_dim)
    encoder_y = Encoder_y(input_dim = y_dim, latent_dim = latent_dim)
    decoder = Decoder(latent_dim = latent_dim, hidden_dim = hidden_dim, output_dim = x_dim)
    model = CVAE_Model(encoder_x, encoder_y, decoder, device).to(device)

    # load data
    train_loader, test_loader = load_data(dataset_path, batch_size)

    if is_train:
        model = train(model,train_loader, batch_size, lr, epochs, x_dim, y_dim, device)
    else:
        # change to your local path
        model.load_state_dict(torch.load('/home/shitao/dss2024/PA2/checkpoints/CVAE.pth'))

    x, x_hat = eval(model, test_loader, batch_size, x_dim, y_dim, device)

    # compare the input image with the recovered image by CVAE
    input_img = x.view(batch_size, 28, 28)
    recovered_img = x_hat.view(batch_size, 28, 28)

    plt.subplot(1,2,1)
    plt.title("input img")
    if device == "cpu":
        input_img_show = input_img[0].numpy()
    else:
        input_img_show = input_img[0].cpu().numpy()
    plt.imshow(input_img_show)
    
    plt.subplot(1,2,2)
    plt.title("recovered img")
    if device == "cpu":
        recovered_img_show = recovered_img[0].numpy()
    else:
        recovered_img_show = recovered_img[0].cpu().numpy()
    plt.imshow(recovered_img_show)
    plt.savefig("/home/shitao/dss2024/PA2/images/comparison.png") # change to your local path
