import numpy as np




def dictionary_learning(X, n_components, alpha, n_iter):
    '''
    X: input data matrix;
    n_components: number of components in the dictionary;
    alpha: hyperparameter in the sparse coding process;
    n_iter: the number of iterations.
    '''
    ## Randomly initialize the dictionary
    D = np.random.randn(X.shape[0], n_components)
    
    for _ in range(n_iter):
        ## Sparse coding step
        Z = sparse_coding(X, D, alpha)

        ## Soft thresholding step
        Z = soft_thresholding(Z, alpha)
        
        ## Dictionary update step
        D = dictionary_update(X, D, Z)
    
    return D


def sparse_coding(X, D, alpha):
    ## Q1(4 points): Solve l1-regularized least squares problem to obtain sparse codes
    ## Hint: np.linalg.lstsq might be useful
    ## TO DO
    Z = None
    
    return Z


def soft_thresholding(Z, alpha):
    ## Q2(3 points): Implement soft(Z, alpha) = sign(Z)·max(|Z| - alpha, 0)
    ## TO DO
    Z = None
    
    return Z


def dictionary_update(X, D, Z):
    # Update each dictionary atom using the sparse codes
    for k in range(D.shape[1]):
        mask = np.ones(D.shape[1], dtype=bool)
        mask[k] = False
        
        ## Q3(3 points): Implement X - sum_{j ≠ k} dj·zj
        ## Hint: Use the mask
        ## TO DO
        E = None

        ## Use SVD to update the components of the dictionary
        U, _, _ = np.linalg.svd(E)
        
        ## Update the dictionary component
        D[:, k] = U[:, 0]
    
    return D




if __name__ == '__main__':
    ## Test case
    m = 64
    p = 100
    X = np.random.randn(m, p)
    n_components = 50
    alpha = 1
    n_iter = 10

    Z = dictionary_learning(X, n_components, alpha, n_iter)


