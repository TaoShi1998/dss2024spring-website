# Dictionary Learning: A Sparse Representation Learning Algorithm


## Overview
Dictionary learning is a sparse representation algorithm that aims to  learn a set of basis vectors, called a dictionary, that can efficiently represent the input data by forming a sparse linear combination of these basis vectors. Dictionary learning is widely used in various computer vision applications, such as image denoising and super-resolution. There are multiple different variations of dictionary learning algorithms, we adopt the [K-SVD approach](https://en.wikipedia.org/wiki/K-SVD). The implementation of dictionary learning is illustrated as follows.


## Step 1: Initialization

The dictionary $D$ is randomly initialized, with a dimension of $m \times n$, where $m$ is the number of features, and $n$ is the number of components in the dictionary.


## Step 2: Sparse Coding

Given the input data matrix $X$ of dimension $m \times p$, where $p$ is the number of samples, and the dictionary $D$, we want to find the sparse coding $Z$ of dimension $n \times p$ such that $X \approx DZ$. This can be formulated as an optimization problem: 
$$\min_{Z} \frac{1}{2} | X - DZ |_{F}^{2} + \alpha | Z |_{1},$$ 
where $| \cdot |_{F}$ denotes the Frobenius norm and $| \cdot |_{1}$ denotes the $l_{1}$-norm.
The solution to this problem can be obtained using techniques like the least squares method with $l_{1}$-norm regularization.


## Step 3: Soft Thresholding

Once we have the sparse coding $Z$, we apply element-wise soft thresholding to enforce sparsity.
Soft thresholding is defined as: 
$$ \text{soft}(x, \alpha) = \text{sign}(x) \cdot \max(|x| - \alpha, 0) $$

This encourages many entries of $Z$ to be close to zero, leading to a sparse representation.


## Step 4: Dictionary Update

Finally, we update each dictionary component $d_{k}$ through the residual error between the input data and the reconstructed data from components other than $d_{k}$. This can be formulated as: 
$$d_{k} = \arg \min_{d_{k}} | X - \sum_{j \neq k} d_{j} z_{j} |_{F}^{2},$$ 
where $z_{j}$ are the columns of $Z$ corresponding to components other than $d_{k}$. This update can be performed iteratively for all components in the dictionary. 

We use the [singular value decomposition (SVD)](https://en.wikipedia.org/wiki/Singular_value_decomposition) to update the components of the dictionary one by one.


## Problem Descriptions
In this programming assignment, you need to implement three functions in [dictionary_learning.py](./dictionary_learning.py). The detailed descriptions are as follows:
- **Question 1 (4 points): Implement `sparse_coding()` function**. Solve the l1-regularized least squares problem to obtain sparse codes.
- **Question 2 (3 points): Implement `soft_thresholding()` function** based on $\text{soft}(x, \alpha) = \text{sign}(x) \cdot \max(|x| - \alpha, 0)$.
- **Question 3 (3 points): Implement part of the `dictionary_update` function**, specifically, calculating the residual error between the input data and the reconstructed data  based on $X - \sum_{j \neq k} d_{j} z_{j}$.


## Policies
Here are some key policies that you need to obey:
- Please submit the [dictionary_learning.py](./dictionary_learning.py) file through the Tsinghua Web Learning Platform. The deadline is **April 23, 2024**.
- Please solve the problems individually. If you collaborate with others, please indicate that in your submission.
- Please feel free to define your own algorithms. **However, the only package you are allowed to use for implementations is numpy.** 


