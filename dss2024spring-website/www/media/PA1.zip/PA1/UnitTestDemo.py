import unittest
import numpy as np


'''
A demonstration of unit testing framework.
'''
class MyClass():

    def __init__(self, x, y):
        self.x = x
        self.y = y

    '''
    Dot product between two vectors.
    '''
    def dot_product(self):
        sum = 0
        for i in range(len(self.x)):
            sum += self.x[i] * self.y[i]
        return sum
    
    '''
    Cosine similarity between two vectors.
    '''
    def cosine_similarity(self):
        dot_product_x_y = self.dot_product()
        x_norm = np.sqrt(np.sum([xi**2 for xi in self.x]))
        y_norm = np.sqrt(np.sum([yi**2 for yi in self.y]))
        cosine_sim = dot_product_x_y / (x_norm * y_norm)
        return cosine_sim




class TestMyClass(unittest.TestCase):
    def __init__(self, methodName = 'runTest'):
        super(TestMyClass, self).__init__(methodName)
        x = np.array([1,3,5,7,9])
        y = np.array([-2,0,2,4,6])
        self.my_class = MyClass(x, y)
    

    '''
    test the implementation of the dot_product function.
    '''
    def test_dot_product(self):
        output = self.my_class.dot_product()
        ground_truth = 90
        self.assertEqual(output, ground_truth)
    

    '''
    test the implementation of the cosine_similarity function.
    '''
    def test_cosine_similarity(self):
        output = self.my_class.cosine_similarity().round(4)
        ground_truth = 0.9045
        self.assertEqual(output, ground_truth)



if __name__ == '__main__':
    unittest.main(verbosity = 2)
