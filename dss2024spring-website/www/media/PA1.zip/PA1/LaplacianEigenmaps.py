import numpy as np
from scipy.linalg import eigh  # Solve a generalized eigenvalue problem.
import unittest



class LaplacianEigenmaps:

    def __init__(self, X, dim, n_neighbors, kernel_param):
        '''
        X: input matrix, X = (x1^T, ..., xk^T)^T, X.shape: (k, l). where k is the number of nodes, l is the dimension of each node xi. 
        dim: dimension of the projected subspace. We need to reduce the dimension of each node from l to "dim". 
        n_neighbors: the number of nearest neighbors for nearest_neighbors graph building.
        kernel_param: parameter of the heat kernel. 
        '''
        self.X = X
        self.dim = dim 
        self.n_neighbors = n_neighbors
        self.kernel_param = kernel_param


    ## Q1(2 points): Calculate the weight between two connected nodes xi and xj using the heat kernel function:
    ## Wij = exp(-||xi - xj||^2 / kernel_param).
    ## Input: two connected nodes xi and xj. xi and xj are both vectors of shape (l, 1).
    ## Return: weight Wij calculated using the heat kernel function.
    def heat_kernel(self, xi, xj):
        ## TO DO
        Wij = 0

        return Wij
    

    ## Construct a pairwise distance matrix P where each element Pij is 
    ## the euclidean distance between nodes xi and xj. 
    ## Note that P is a symmetric matrix where the diagonal elements are all zeros.
    def construct_distance_matrix(self):
        distance_matrix = np.zeros((self.X.shape[0], self.X.shape[0]))
        for i in range(distance_matrix.shape[0]):
            for j in range(distance_matrix.shape[1]):
                if i != j:
                    distance_matrix[i][j] = np.sqrt(np.sum([(self.X[i][k] - self.X[j][k])**2 for k in range(len(self.X[i]))]))

        return distance_matrix
    

    ## Construct a weight matrix W where each element Wij satisfies the following requirements: 
    ## if node xi is among the "n_neighbors" number of nearest neighbors of node xj or vice versa, 
    ## nodes xi and xj are connected by an edge and the weight on the edge Wij will be calculated 
    ## by the heat kernel function. Otherwise, nodes xi and xj are not connected and Wij will be set to 0. 
    def construct_weight_matrix(self):
        distance_matrix = self.construct_distance_matrix()
        distance_ranks = np.argsort(distance_matrix, axis = 1)[:, 1 : self.n_neighbors + 1]
        weight_matrix = np.zeros((self.X.shape[0], self.X.shape[0]))
        for i in range(distance_ranks.shape[0]):
            for j in range(distance_ranks.shape[1]):
                index = distance_ranks[i][j]
                weight_matrix[i][index] = self.heat_kernel(self.X[i], self.X[index])  
                weight_matrix[index][i] = weight_matrix[i][index]

        return weight_matrix
    

    ## Q2(2 points): Construct a laplacian matrix L using L = D - W, where D is a diagonal 
    ## weight matrix and its entries are column(or row) sums of the weight matrix W.
    ## Return: laplacian matrix L and diagonal weight matrix D.
    def construct_laplacian_matrix(self):
        ## TO DO
        weight_matrix = self.construct_weight_matrix()
        diagonal_matrix = np.zeros(weight_matrix.shape)
        laplacian_matrix = np.zeros(weight_matrix.shape)

        return laplacian_matrix, diagonal_matrix


    ## Q3(2 points): Obtain the eigenvectors of the laplacian matrix L ordered by their eigenvalues,
    ## leave out the eigenvector corresponding to eigenvalue 0 and use the next "dim" 
    ## number of eigenvectors as the embedding for input X.
    ## Hint: The imported eigh function might be useful here. Note that the outputs of eigh are already sorted. 
    ## Return: "dim" number of eigenvectors as the output embedding.
    def construct_embeddings(self):
        ## TO DO
        laplacian_matrix, diagonal_matrix = self.construct_laplacian_matrix()
        embedding = np.zeros((self.X.shape[0], self.dim))

        return embedding



'''
Please do not modify the following code.
Unit test section to check the correctness of your implementations.  
'''
## Please do not change the seed.
SEED = 100
np.random.seed(SEED)

# X is a test input to laplacian eigenmaps. 
test_X = np.random.randn(4, 6) 


class LaplacianEigenmapsTest(unittest.TestCase):

    def __init__(self, methodName = 'runTest'):
        super(LaplacianEigenmapsTest, self).__init__(methodName)
        # Reduce the dimension of X from 6 to 2.
        self.lp = LaplacianEigenmaps(X = test_X, dim = 2, n_neighbors = 3, kernel_param = 2)
    
    '''
    Testing the heat kernel function.
    '''
    def test_heat_kernel(self):
        Xi = self.lp.X[0]
        Xj = self.lp.X[1]
        output = self.lp.heat_kernel(Xi, Xj)
        if not isinstance(output, int):
            output = output.round(6)
        ground_truth = 0.006677
        self.assertEqual(output, ground_truth)
    

    '''
    Testing the laplacian matrix function.
    '''
    def test_laplacian_matrix(self):
        output_1, output_2 = self.lp.construct_laplacian_matrix()
        output_1, output_2 = output_1.round(6), output_2.round(6)
        ground_truth_1 = np.array([
            [ 0.122837, -0.006677, -0.111296, -0.004864],
            [-0.006677, 0.102201, -0.065892, -0.029633],
            [-0.111296, -0.065892, 0.18137, -0.004182],
            [-0.004864, -0.029633, -0.004182, 0.038679]])
        ground_truth_2 = np.array([
            [0.122837, 0, 0, 0],
            [0, 0.102201, 0, 0],
            [0, 0, 0.18137, 0],
            [0, 0, 0, 0.038679]])
        self.assertEqual(output_1.tolist(), ground_truth_1.tolist())
        self.assertEqual(output_2.tolist(), ground_truth_2.tolist())
    
    
    '''
    Testing the eigenmaps function.
    '''
    def test_construct_embeddings(self):
        output = self.lp.construct_embeddings().round(6)
        ground_truth = np.array([
            [1.369716, 1.276416],
            [-1.571192, -1.7657],
            [0.672961, -0.573571],
            [-3.353976, 3.301388]])
        self.assertEqual(output.tolist(), ground_truth.tolist())



if __name__ == '__main__':
    unittest.main(verbosity = 2)
    
    








